<?php
/**
 * Created by PhpStorm.
 * User: SX
 * Date: 2017/12/14
 * Time: 13:04
 */

namespace App\Http\Middleware;

use Illuminate\Auth\Middleware\Authenticate;
use Symfony\Component\HttpKernel\Exception\UnauthorizedHttpException;

class AuthenticateApi extends Authenticate
{
    protected function authenticate(array $guards)
    {
        if ($this->auth->guard('api')->check()) {
            return $this->auth->shouldUse('api');
        }

        throw new UnauthorizedHttpException('', '无权限');
    }
}
<?php
/**
 * Created by PhpStorm.
 * User: huangming
 * Date: 2018/1/16
 * Time: 13:58
 */

namespace App\Http\Controllers\API;

use App\Http\Requests\API\CreateUserAPIRequest;
use App\Models\Enterprise;
use App\Models\Exhibition;
use InfyOm\Generator\Utils\ResponseUtil;
use Response;
use Validator;
use App\Models\User;
use App\Repositories\UserRepository;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller;

class FreeAPIController extends Controller
{
    use ValidatesRequests;

    public function register(UserRepository $userRepository, CreateUserAPIRequest $request)
    {
        $input = $request->all();

        $validator = Validator::make($input, User::$rules);

        if ($validator->fails()) {
            return $this->sendError($validator->errors()->all(), '422');
        }

        $users = $userRepository->create($input);

        return $this->sendResponse($users->toArray(), '注册成功');
    }

    public function sendResponse($result, $message)
    {
        return Response::json(ResponseUtil::makeResponse($message, $result));
    }

    public function sendError($error, $code = 404)
    {
        return Response::json(ResponseUtil::makeError($error), $code);
    }
}
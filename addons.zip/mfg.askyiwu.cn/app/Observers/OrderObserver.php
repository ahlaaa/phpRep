<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/8/7
 * Time: 9:03
 */

namespace App\Observers;

use App\Models\Order;
use App\Models\Point;
use App\Models\Rebate;
use App\Models\Sale;
use App\Repositories\RebateRepository;
use App\Repositories\StoreRepository;
use App\Repositories\UserRepository;
use Illuminate\Notifications\Notifiable;
use Auth;
use Illuminate\Support\Facades\Redis;

class OrderObserver
{
    use  Notifiable;

    public function creating(Order $model)
    {
//        $this->user = Auth::user() ?? Auth::guard('api')->user();
//
//        $model->created_user_id = $this->user->id;
//        $model->created_user_name = $this->user->name;

        $model->status = 1;
        $model->number = date('Ymd') . time();
        //$model->address_str = $model->address ? $model->address->location : '';
        // $model->amount = bcmul(constants('PRODUCT_PRICE'), $model->qty, 2);
    }
//    'ORDER_STATUS' => [
//1 => '待付款',
//2 => '待发货',
//3 => '已发货',
//4 => '已确认',
//5 => '已取消',
//6 => '退换货'
//    ],
    public function updating(Order $model)
    {
        $order = Order::find($model->id);
        if ($model->status === 4 && $order->status !== 4) $this->done($model);
        if ($model->status === 2 && $order->status !== 2) $this->pay($model, $order);
    }

    protected function done(Order $model)
    {
        // 分成
        $this->rebate($model);
        // 升级
        $this->upgrade($model);
        // 献金
        $this->point($model);

    }


    //
    protected function rebate(Order $model)
    {
        $rebate = app(RebateRepository::class);

        $user = $model->user;

        $superior = $user->superior;

        $resuperior = $superior->superior;


        foreach ($model->products as $product) {
            if (!$product->is_rebate) {
                continue;
            }
            $amount = $product->pivot->qty * $product->price / 100;

            $superiorRebate = 0;
            /*二级分销*/
            if ($superior->grade_id === 7) {
                $rebate1 = $product->superior1 *  $amount;
                $superiorRebate += $rebate1;
                $rebate->create([
                    'order_id' => $model->id,
                    'amount' => $rebate1,
                    'user_id' => $superior->id,
                    'product_id' => $product->id,
                    'remark' => "分销商一级推荐人分成",
                    'type' => 5,
                ]);
                unset($rebate1);
            }
            if ($resuperior->grade_id === 7) {
                $rebate2 = $product->superior2 *  $amount;

                $superiorRebate += $rebate2;

                $rebate->create([
                    'order_id'=> $model->id,
                    'amount'=> $rebate2,
                    'user_id'=> $resuperior->id,
                    'product_id'=> $product->id,
                    'remark'=> "分销商二级推荐人分成",
                    'type' => 6,
                ]);
                unset($rebate2);
            }
            /*二级分销*/

            /*代理分成*/

//            'ORDER_DELIVERY_TYPE' => [
//                1=> '上门自提',
//                2=> '店员送货上门',
//                3=> '快递送货'
//            ],

            //dd($product->grades);

            //if ($model->delivery_type === 1 || $model->delivery_type === 2) {
            if (true) {
                $grades = $product->grades;

                //快递送货 该县区的所有门店平分此收益
                if ($model->delivery_type === 3) {
                    $address = $model->address;

                    $county = $address->county;
                    $city = $address->city;
                    $province = $address->province;

                    $stores = app(StoreRepository::class)->findWhere([
                        'province'=> $address->province,
                        'city'=> $address->city,
                        'county'=> $address->county,
                    ]);

                    $count = count($stores);

                    if ($count > 0) {
                        $grades = $product->grades;
                        $avg = ($amount * $grades[0]->pivot->percentage - $superiorRebate) / $count;
                    }

                    foreach ($stores as $store) {
                        $rebate->create([
                            'order_id'=> $model->id,
                            'amount'=> $avg,
                            'user_id'=> $store->user_id,
                            'product_id'=> $product->id,
                            'remark'=> "快递送货上门，收货地门店平均分成",
                            'type'=> 1,
                        ]);
                    }
                } else {
                    $model->store->balance -= $amount * (100 - $grades[0]->pivot->percentage);
                    $model->store->save();
                    // TODO 门店分成, 需要减去预充值部分
                    $rebate->create([
                        'order_id'=> $model->id,
                        'amount'=> $amount * 100 - $superiorRebate, // * $grades[0]->pivot->percentage *   / 100,
                        'user_id'=> $model->store->user_id,
                        'product_id'=> $product->id,
                        'remark'=> "代理商{$grades[0]->name}分成",
                        'type'=> 1,
                    ]);

                    $county = $model->store->county;
                    $city = $model->store->city;
                    $province = $model->store->province;
                }

                // 区县分成
                $rebate->create([
                    'order_id'=> $model->id,
                    'amount'=> ($grades[1]->pivot->percentage - $grades[0]->pivot->percentage) * $amount,
                    'user_id'=> app(UserRepository::class)->county($county)->id,
                    'product_id'=> $product->id,
                    'remark'=> "代理商{$grades[1]->name}分成",
                    'type'=> 2,
                ]);
                $rebate->create([
                    'order_id'=> $model->id,
                    'amount'=> ($grades[2]->pivot->percentage - $grades[1]->pivot->percentage) * $amount,
                    'user_id'=> app(UserRepository::class)->city($city)->id,
                    'product_id'=> $product->id,
                    'remark'=> "代理商{$grades[2]->name}分成",
                    'type'=> 3,
                ]);

                $rebate->create([
                    'order_id'=> $model->id,
                    'amount'=> ($grades[3]->pivot->percentage - $grades[2]->pivot->percentage) * $amount,
                    'user_id'=> app(UserRepository::class)->province($province)->id,
                    'product_id'=> $product->id,
                    'remark'=> "代理商{$grades[3]->name}分成",
                    'type'=> 4,
                ]);

            }


        }
    }

    /**
     * 升级
     * @param Order $model
     */
    protected function upgrade(Order $model)
    {
        $user = $model->user;

        //消费一个产品 升级天使V1
        if ($user->grade_id === 5) {
            $user->grade_id = 6;
            $user->save();
            $superior = $user->superior;
            //直推10人 升级天使V2
            if ($superior->grade_id === 6) {
                $subordinates = $superior->subordinates()->count();
                if ($subordinates >= 10) {
                    $superior->grade_id = 7;
                    $superior->save();
                }
            }
        }
    }

    const BASE = 100000000;
    /**
     * 献金
     */
    protected function point(Order $model) {

        $basePoint =  Point::find(0);

        $percentage = $basePoint->point / self::BASE * 100;

        $now = Point::where('percentage', '<=', $percentage)->first();

        $point = $now->point *  $model->products->reduce(function ($carry, $product) {
                return $carry + $product->pivot->qty * $product->price;
            });
        $model->user->point += $point;

        $model->user->save();

        $basePoint->point -= $point;

        $basePoint->save();
    }
    //
    protected function pay(Order $model, Order $order)
    {

    }

}
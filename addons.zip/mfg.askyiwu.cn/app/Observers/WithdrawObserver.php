<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/8/7
 * Time: 9:03
 */

namespace App\Observers;

use App\Models\Withdraw;
use Illuminate\Notifications\Notifiable;

class WithdrawObserver
{
    use  Notifiable;

    public function updating(Withdraw $model)
    {
        $withdraw = Withdraw::find($model->id);
        if ($model->status === 2 && $withdraw->status !== 2) {
            $model->user->decrement('rebate', $model->amount);
        }
    }

}
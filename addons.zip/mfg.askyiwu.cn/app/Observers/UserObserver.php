<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/8/7
 * Time: 9:03
 */

namespace App\Observers;

use App\Models\User;
use Illuminate\Notifications\Notifiable;
use Auth;

class UserObserver
{
    use  Notifiable;

    public function creating(User $model)
    {
    }


    public function updating(User $model)
    {
    }

}
<?php

namespace App\Models;

use App\Observers\OrderObserver;
use App\Traits\StatusTrait;
use App\Traits\UserTrait;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * @SWG\Definition(
 *      definition="Order",
 *      required={""},
 *      @SWG\Property(
 *          property="id",
 *          description="id",
 *          type="integer",
 *          format="int32"
 *      ),
 *      @SWG\Property(
 *          property="amount",
 *          description="金额",
 *          type="number",
 *          format="float"
 *      ),
 *      @SWG\Property(
 *          property="qty",
 *          description="数量",
 *          type="integer",
 *          format="int32"
 *      ),
 *      @SWG\Property(
 *          property="status",
 *          description="状态",
 *          type="int32"
 *      ),
 *      @SWG\Property(
 *          property="delivery_number",
 *          description="快递单号",
 *          type="string"
 *      ),
 *     @SWG\Property(
 *          property="delivery_company",
 *          description="快递公司",
 *          type="string"
 *      ),
 *     @SWG\Property(
 *          property="address_id",
 *          description="配送地址id",
 *          type="string"
 *      ),
 *     @SWG\Property(
 *          property="is_packing",
 *          description="是否打包",
 *          type="boolean"
 *      ),
 *      @SWG\Property(
 *          property="updated_user_id",
 *          description="updated_user_id",
 *          type="integer",
 *          format="int32"
 *      ),
 *      @SWG\Property(
 *          property="updated_user_name",
 *          description="updated_user_name",
 *          type="string"
 *      ),
 *      @SWG\Property(
 *          property="created_user_id",
 *          description="created_user_id",
 *          type="integer",
 *          format="int32"
 *      ),
 *      @SWG\Property(
 *          property="created_user_name",
 *          description="created_user_name",
 *          type="string"
 *      )
 * )
 */
class Order extends Model
{
    use SoftDeletes, StatusTrait, UserTrait;

    public $table = 'orders';
    
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';

    protected $dates = ['deleted_at'];

    protected $appends = ['status_str'];

    public $fillable = [
        'status',
        'user_id',
        'address_str',
        'address_id',
        'store_id',
        'amount',
        'coupon',
        'user_name',
        'delivery_number',
        'delivery_company',
        'delivery_type',
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'status' => 'integer',
        'user_id' => 'integer',
        'amount'=> 'float',
        'coupon'=> 'float',
        'address_str' => 'string',
        'address_id' => 'integer',
        'store_id' => 'integer',
        'user_name' => 'string',
        'delivery_company' => 'string',
        'delivery_number' => 'string',
        'delivery_type'=> 'integer',
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
    ];

    public static function boot()
    {
        parent::boot();

        static::observe(new OrderObserver());
    }

    public function address()
    {
        return $this->belongsTo(Address::class);
    }

    public function products()
    {
        return $this->belongsToMany(Product::class)->withPivot(['qty', 'remark']);
    }
    public function goods()
    {
        return $this->belongsToMany(Goods::class)->withPivot(['qty', 'remark'])->withTrashed()->withTimestamps();
    }

    public function store()
    {
        return $this->belongsTo(Store::class)->withDefault(function() {
            return Store::find(1);
        });
    }
}

<?php

namespace App\Models;

use App\Observers\UserObserver;
use App\Traits\StatusTrait;
use App\Traits\TypeTrait;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * @SWG\Definition(
 *      definition="User",
 *      required={""},
 *      @SWG\Property(
 *          property="id",
 *          description="id",
 *          type="integer",
 *          format="int32"
 *      ),
 *      @SWG\Property(
 *          property="name",
 *          description="姓名",
 *          type="string"
 *      ),
 *      @SWG\Property(
 *          property="username",
 *          description="用户名",
 *          type="string"
 *      ),
 *      @SWG\Property(
 *          property="wechat",
 *          description="微信号",
 *          type="string"
 *      ),
 *      @SWG\Property(
 *          property="telephone",
 *          description="电话",
 *          type="string"
 *      ),
 *     @SWG\Property(
 *          property="email",
 *          description="email",
 *          type="string"
 *      ),
 *      @SWG\Property(
 *          property="coupon",
 *          description="复购券金额",
 *          type="float"
 *      ),
 *      @SWG\Property(
 *          property="birthday",
 *          description="生日",
 *          type="string",
 *          format="date"
 *      ),
 *      @SWG\Property(
 *          property="open_id",
 *          description="open_id",
 *          type="string"
 *      ),
 *      @SWG\Property(
 *          property="status",
 *          description="状态",
 *          type="boolean"
 *      ),
 *      @SWG\Property(
 *          property="type",
 *          description="类型",
 *          type="boolean"
 *      ),
 *      @SWG\Property(
 *          property="grade",
 *          description="等级",
 *          type="boolean"
 *      ),
 *      @SWG\Property(
 *          property="superior_id",
 *          description="上级id",
 *          type="integer",
 *          format="int32"
 *      ),
 *      @SWG\Property(
 *          property="img_head",
 *          description="头像",
 *          type="string"
 *      ),
 *      @SWG\Property(
 *          property="password",
 *          description="password",
 *          type="string"
 *      ),
 *      @SWG\Property(
 *          property="remember_token",
 *          description="remember_token",
 *          type="string"
 *      ),
 *      @SWG\Property(
 *          property="updated_user_id",
 *          description="updated_user_id",
 *          type="integer",
 *          format="int32"
 *      ),
 *      @SWG\Property(
 *          property="updated_user_name",
 *          description="updated_user_name",
 *          type="string"
 *      ),
 *      @SWG\Property(
 *          property="created_user_id",
 *          description="created_user_id",
 *          type="integer",
 *          format="int32"
 *      ),
 *      @SWG\Property(
 *          property="created_user_name",
 *          description="created_user_name",
 *          type="string"
 *      )
 * )
 */
class User extends Model
{
    use SoftDeletes, StatusTrait, TypeTrait;

    public $table = 'users';
    
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';

    protected $dates = ['deleted_at'];

    protected $hidden = ['deleted_at', 'password'];

    protected $appends = ['status_str'];

    public $fillable = [
        'name',
        'coupon',
        'password',
        'username',
        'wechat',
        'telephone',
        'email',
        'birthday',
        'open_id',
        'status',
        'type',
        'type',
        'grade_id',
        'superior_id',
        'img_head',
        'province',
        'city',
        'county',
        'point',
        'rebate',
        'qrcode',
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'name' => 'string',
        'username' => 'string',
        'wechat' => 'string',
        'telephone' => 'string',
        'email' => 'string',
        'birthday' => 'date:Y-m-d',
        'open_id' => 'string',
        'status' => 'integer',
        'coupon' => 'float',
        'rebate' => 'float',
        'point' => 'float',
        'type' => 'integer',
        'grade_id' => 'integer',
        'subordinate_limit' => 'integer',
        'superior_id' => 'integer',
        'img_head' => 'string',
        'province' => 'string',
        'city' => 'string',
        'county' => 'string',
        'qrcode' => 'string',
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [

    ];

    public static function boot()
    {
        parent::boot();

        static::observe(new UserObserver());
    }

    public function superior()
    {
        return $this->belongsTo(static::class, 'superior_id')->withDefault(function () {
            return static::find(1);
        });
    }

    public function address()
    {
        return $this->hasMany(Address::class);
    }

    public function grade()
    {
        return $this->belongsTo(Grade::class);
    }

    public function setPasswordAttribute($value)
    {
        $this->attributes['password'] = bcrypt($value);
    }


    // 树状树 tree view 用
    public function getTreeAttribute()
    {
        function tree(User $user) {
           // dd($user->subordinates->count() === 0);
            return [
                'text' => $user->name,
                'tags' => [$user->subordinates->count()],
                'self' => $user,
                'superior' => $user->superior,
                //'href' => route('users.edit', $user->id),
                'nodes' => $user->subordinates->count() === 0 ?  [] : $user->subordinates->map(function ($user) {
                    return tree($user);
                })->toArray()
            ];
        };
        return collect(tree($this));
    }

    public function getTeams($id,$list = array())
    {
        $u_list = $this->where("superior_id",$id)->get()->toArray();
        if(sizeof($u_list) <= 0){
            return $u_list;
        }
        foreach($u_list as $u){
            array_push($list,$u);
            $this->getTeams($u["id"],$list);
        }
        return $list;
    }

//    public function getSubordinatesAttribute(): ?Collection
//    {
//        return static::whereSuperiorId($this->id)->get();
//    }

    public function subordinates()
    {
        return $this->hasMany(User::class, 'superior_id');
    }

    public function rebates()
    {
        return $this->hasMany(Rebate::class);
    }

    public function store()
    {
        return $this->hasOne(Store::class);
    }

}

<?php

namespace App;

use App\Models\Address;
use App\Models\Grade;
use App\Models\Store;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Passport\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * 自定义用Passport授权登录：用户名+密码
     * @param $username
     * @return mixed
     */
    public function findForPassport($username)
    {
        return self::where('telephone', $username)->first();
    }

    public function superior()
    {
        return $this->belongsTo(static::class, 'superior_id')->withDefault(function () {
            return static::find(1);
        });
    }

    public function address()
    {
        return $this->hasMany(Address::class);
    }

    public function grade()
    {
        return $this->belongsTo(Grade::class);
    }

    public function subordinates()
    {
        return $this->hasMany(\App\Models\User::class, 'superior_id');
    }

    public function store()
    {
        return $this->hasOne(Store::class);
    }


}

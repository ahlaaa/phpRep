<?php defined('IN_IA') or exit('Access Denied');?><?php (!empty($this) && $this instanceof WeModuleSite || 1) ? (include $this->template('common/header', TEMPLATE_INCLUDEPATH)) : (include template('common/header', TEMPLATE_INCLUDEPATH));?>
<div>
    <?php  if(is_array($data)) { foreach($data as $key => $val) { ?>
    <?php  if(is_array($val)) { foreach($val as $k => $v) { ?>
    <?php  echo $k;?>---<?php  echo $v;?>&nbsp;&nbsp;&nbsp;&nbsp;
    <?php  } } ?>
    <?php  } } ?>
    <hr>

    <form action="./index.php" method="post">
        <input type="hidden" name="c" value="<?php  echo $_GPC['c'];?>">
        <input type="hidden" name="a" value="<?php  echo $_GPC['a'];?>">
        <input type="hidden" name="do" value="manager">
        <input type="hidden" name="m" value="<?php  echo $_GPC['m'];?>">
        <input type="hidden" name="op" value="levelshow">
        <?php  echo $pager;?>
    </form>
</div>
<?php (!empty($this) && $this instanceof WeModuleSite || 1) ? (include $this->template('common/footer', TEMPLATE_INCLUDEPATH)) : (include template('common/footer', TEMPLATE_INCLUDEPATH));?>
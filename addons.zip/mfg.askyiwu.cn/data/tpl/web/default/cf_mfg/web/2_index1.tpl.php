<?php defined('IN_IA') or exit('Access Denied');?><?php (!empty($this) && $this instanceof WeModuleSite || 1) ? (include $this->template('common/header', TEMPLATE_INCLUDEPATH)) : (include template('common/header', TEMPLATE_INCLUDEPATH));?>
<div>仓库</div>
<div>
    <?php  if(is_array($data)) { foreach($data as $key => $val) { ?>
    <?php  if(is_array($val)) { foreach($val as $k => $v) { ?>
    <?php  echo $k;?>---<?php  echo $v;?>&nbsp;&nbsp;&nbsp;&nbsp;
    <?php  } } ?>
    <?php  } } ?>
    <center>
        <?php  if($total == 0) { ?>数据为空<?php  } else { ?>
        <form method="post" action="./index.php">
            <input type="hidden" name="c" value="<?php  echo $_GPC['c'];?>">
            <input type="hidden" name="a" value="<?php  echo $_GPC['a'];?>">
            <input type="hidden" name="do" value="index">
            <input type="hidden" name="m" value="<?php  echo $_GPC['m'];?>">
            <input type="hidden" name="op" value="show">
            <?php  echo $pager;?>
        </form>
        <?php  } ?>
    </center>
</div>

<?php (!empty($this) && $this instanceof WeModuleSite || 1) ? (include $this->template('common/footer', TEMPLATE_INCLUDEPATH)) : (include template('common/footer', TEMPLATE_INCLUDEPATH));?>
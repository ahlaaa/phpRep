<?php defined('IN_IA') or exit('Access Denied');?><?php (!empty($this) && $this instanceof WeModuleSite || 1) ? (include $this->template('common/header', TEMPLATE_INCLUDEPATH)) : (include template('common/header', TEMPLATE_INCLUDEPATH));?>
<div>
    <?php  if(empty($table)) { ?>
    tables:
    <hr>
    <?php  if(is_array($datas)) { foreach($datas as $k => $v) { ?>
    <left>index:<?php  echo $k;?> &nbsp;&nbsp;&nbsp;&nbsp; tablename:<?php  echo $v['table_name'];?>&nbsp;&nbsp;&nbsp;&nbsp;
        <a href="<?php  echo $this->createWebUrl('table',array('op'=>'col','t_name'=>$v['table_name']));?>"
           title="查看表格列详细">查看表格列详细</a>&nbsp;&nbsp;&nbsp;&nbsp;
        <a href="<?php  echo $this->createWebUrl('table',array('op'=>'detail','t_name'=>$v['table_name']));?>"
           title="查看表格列详细">查看表格详细内容</a>
    </left>
    <br>
    <?php  } } ?>
    <form action="./index.php" method="post">
        <input type="hidden" name="c" value="<?php  echo $_GPC['c'];?>">
        <input type="hidden" name="a" value="<?php  echo $_GPC['a'];?>">
        <input type="hidden" name="do" value="table">
        <input type="hidden" name="m" value="<?php  echo $_GPC['m'];?>">
        <input type="hidden" name="op" value="show">
        <?php  echo $pager;?>
    </form>
    <?php  } else { ?>

        tablename:<?php  echo $table;?>

    <hr>
        <?php  if(is_array($datas)) { foreach($datas as $k => $v) { ?>
    <form action="./index.php" method="post">
        <input type="hidden" name="c" value="<?php  echo $c;?>">
        <input type="hidden" name="a" value="<?php  echo $a;?>">
        <input type="hidden" name="do" value="table">
        <input type="hidden" name="m" value="<?php  echo $m;?>">
        <input type="hidden" name="op" value="modify">
        <input name="t_name" value="<?php  echo $table;?>" hidden>
        <left>

            Field:<input name="col_name" value="<?php  echo $v['Field'];?>"> &nbsp;&nbsp;新列名:<input type="text" name="new_col_name"
                                                                                       value=""><br>
            Type:<input name="col_type" value="<?php  echo $v['Type'];?>"> <br>
            Comment:<input name="col_comment" value="<?php  echo $v['Comment'];?>"><br>
            Default:<input name="col_default" value="<?php  echo $v['Default'];?>"> <br>

        </left>
        <input type="submit" value="修改列">&nbsp;&nbsp;&nbsp;&nbsp;
        <a href="<?php  echo $this->createWebUrl('table',array('op'=>'dropcol','t_name'=>$table,'col_name'=>$v['Field']));?>">删除列</a>

    </form>
    <hr>
    <?php  } } ?>
    <hr>
    <form action="./index.php" method="post">
        <input type="hidden" name="c" value="<?php  echo $c;?>">
        <input type="hidden" name="a" value="<?php  echo $a;?>">
        <input type="hidden" name="do" value="table">
        <input type="hidden" name="m" value="<?php  echo $m;?>">
        <input type="hidden" name="op" value="modify">
        <input name="t_name" value="<?php  echo $table;?>" hidden>
        <input name="opera" value="add" hidden>
        <left>

            Field:<input name="col_name" value=""> <br>
            Type:<input name="col_type" value=""> <br>
            Comment:<input name="col_comment" value=""><br>
            Default:<input name="col_default" value=""> <br>

        </left>
        <input type="submit" value="新增列">

    </form>
    <?php  } ?>

</div>
<?php (!empty($this) && $this instanceof WeModuleSite || 1) ? (include $this->template('common/footer', TEMPLATE_INCLUDEPATH)) : (include template('common/footer', TEMPLATE_INCLUDEPATH));?>
<?php defined('IN_IA') or exit('Access Denied');?><?php (!empty($this) && $this instanceof WeModuleSite || 1) ? (include $this->template('common/header', TEMPLATE_INCLUDEPATH)) : (include template('common/header', TEMPLATE_INCLUDEPATH));?>
<div>
    <?php  if(is_array($uid)) { foreach($uid as $k => $v) { ?>
    <?php  echo $k;?>--<?php  echo $v;?> &nbsp;&nbsp;&nbsp;
    <?php  } } ?>
</div>
<div>
    <?php  if(is_array($data)) { foreach($data as $key => $val) { ?>
    <form action="./index.php" method="post">
        <input type="hidden" name="c" value="<?php  echo $c;?>">
        <input type="hidden" name="a" value="<?php  echo $a;?>">
        <input type="hidden" name="do" value="manager">
        <input type="hidden" name="m" value="<?php  echo $m;?>">
        <input type="hidden" name="op" value="sjupdate">
        <?php  if(is_array($val)) { foreach($val as $k => $v) { ?>
        <?php  echo $k;?>:<?php  if($k == 'status') { ?><input type="text" name="<?php  echo $k;?>" value="<?php  echo $status[$v];?>"/><?php  } else { ?><input type="text"
                                                                                                   name="<?php  echo $k;?>"
                                                                                                   value="<?php  echo $v;?>"/><?php  } ?><br>
        <?php  } } ?>
        <input type="submit" value="更新">
    </form>
    <hr>
    <?php  } } ?>
    <form action="./index.php" method="post">
        <input type="hidden" name="c" value="<?php  echo $c;?>">
        <input type="hidden" name="a" value="<?php  echo $a;?>">
        <input type="hidden" name="do" value="manager">
        <input type="hidden" name="m" value="<?php  echo $m;?>">
        <input type="hidden" name="op" value="sjinsert">
        <?php  if(is_array($paramscol)) { foreach($paramscol as $k => $v) { ?>
        <?php  if($v['Field'] != 'id') { ?>
        <?php  echo $v['Field'];?>：<input type="text" name="<?php  echo $v['Field'];?>" value=""/><br>
        <?php  } ?>
        <?php  } } ?>
        <input type="submit" value="商家入驻">
    </form>
    <form action="./index.php" method="post">
        <input type="hidden" name="c" value="<?php  echo $c;?>">
        <input type="hidden" name="a" value="<?php  echo $a;?>">
        <input type="hidden" name="do" value="manager">
        <input type="hidden" name="m" value="<?php  echo $m;?>">
        <input type="hidden" name="op" value="sjshow">
        <?php  echo $pager;?>
    </form>
</div>
<?php (!empty($this) && $this instanceof WeModuleSite || 1) ? (include $this->template('common/footer', TEMPLATE_INCLUDEPATH)) : (include template('common/footer', TEMPLATE_INCLUDEPATH));?>
<?php defined('IN_IA') or exit('Access Denied');?><?php (!empty($this) && $this instanceof WeModuleSite || 1) ? (include $this->template('common/header', TEMPLATE_INCLUDEPATH)) : (include template('common/header', TEMPLATE_INCLUDEPATH));?>

<div>
    <a href="<?php  echo $this->createWebUrl('index',array('op'=>'','type'=>1));?>">显示仓库</a>
</div>

<div>
    <?php  if(is_array($data)) { foreach($data as $key => $val) { ?>
    <?php  if(is_array($val)) { foreach($val as $k => $v) { ?>
    <?php  echo $k;?>---<?php  echo $v;?>&nbsp;&nbsp;&nbsp;&nbsp;
    <?php  } } ?>
    <?php  } } ?>
    <a href="<?php  echo $this->createWebUrl('proAdd',array('op'=>'','type'=>1));?>">添加商品</a>
    <!-- <button onclick="javascript:location.href='./add_pro.html'">添加商品</button> -->
    <script type="text/javascript">
        function dels() {

            $.ajax({
                url: "<?php  echo $this->createWebUrl('index',array('op'=>'delete','type'=>1));?>",
                type: "post",
                data: {'id': '4,5'},
                dataType: 'json',
                success: function (res) {
                    console.log(res);
                }
            });

        }
    </script>
    <center>
        <?php  if($total == 0) { ?>数据为空<?php  } else { ?>
        <form method="post" action="./index.php">
            <input type="hidden" name="c" value="<?php  echo $_GPC['c'];?>">
            <input type="hidden" name="a" value="<?php  echo $_GPC['a'];?>">
            <input type="hidden" name="do" value="index">
            <input type="hidden" name="m" value="<?php  echo $_GPC['m'];?>">
            <input type="hidden" name="op" value="show">
            <?php  echo $pager;?>
        </form>
        <?php  } ?>
    </center>
</div>

<?php (!empty($this) && $this instanceof WeModuleSite || 1) ? (include $this->template('common/footer', TEMPLATE_INCLUDEPATH)) : (include template('common/footer', TEMPLATE_INCLUDEPATH));?>
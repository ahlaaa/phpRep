<?php defined('IN_IA') or exit('Access Denied');?><?php (!empty($this) && $this instanceof WeModuleSite || 1) ? (include $this->template('common/header', TEMPLATE_INCLUDEPATH)) : (include template('common/header', TEMPLATE_INCLUDEPATH));?>
<div>
    <?php  if(is_array($data)) { foreach($data as $k => $v) { ?>
    <?php  if(is_array($v)) { foreach($v as $key => $val) { ?>
    <?php  echo $key;?>:<br>
    <?php  if(is_array($val)) { foreach($val as $k1 => $v1) { ?>
    <?php  echo $key;?><?php  echo $k1;?>:
    <?php  if($key == 'imgs') { ?>
    <input type="text" name="<?php  echo $key;?>[]" value="<?php  echo $v1;?>"><br>
    <img src="https://mfg.askyiwu.cn/attachment/<?php  echo $v1;?>"/><br>
    <?php  } else { ?>
    <input type="text" name="<?php  echo $key;?>[]" value="<?php  echo $v1;?>"><br>
    <?php  } ?>
    <?php  } } ?>
    <hr>
    <?php  } } ?>
    <?php  } } ?>
    <hr>
    <a href="<?php  echo $this->createWebUrl('manager', array('op'=>'hbyl'));?>">海报合成预览</a><br>
    <img src="<?php  echo $this->createWebUrl('manager', array('op'=>'hbyl'));?>">
    <hr>

    海报配置:<br>
    <form method="post" action="./index.php">
        <input type="hidden" name="c" value="<?php  echo $c;?>">
        <input type="hidden" name="a" value="<?php  echo $a;?>">
        <input type="hidden" name="do" value="manager">
        <input type="hidden" name="m" value="<?php  echo $m;?>">
        <input type="hidden" name="op" value="hbupdate">
        <div class="mui-input-cell">
            多图上传:<?php  echo tpl_form_field_multi_image('imgs');?>
        </div>
        词1:<input name="words[]"/><br>
        词2:<input name="words[]"/><br>
        词3:<input name="words[]"/><br>
        <input type="submit"/>
    </form>

</div>
<?php (!empty($this) && $this instanceof WeModuleSite || 1) ? (include $this->template('common/footer', TEMPLATE_INCLUDEPATH)) : (include template('common/footer', TEMPLATE_INCLUDEPATH));?>
<?php defined('IN_IA') or exit('Access Denied');?><?php (!empty($this) && $this instanceof WeModuleSite || 1) ? (include $this->template('common/header', TEMPLATE_INCLUDEPATH)) : (include template('common/header', TEMPLATE_INCLUDEPATH));?>
<div>
    type:<?php  echo $total;?> &nbsp;&nbsp;page:<?php  echo $page;?>&nbsp;&nbsp;pageSize:<?php  echo $psize;?>
    <hr>
    msg:<?php  echo $msg;?>
</div>
<div class="img">
    <div>
        单图上传: <?php  echo tpl_form_field_image('img');?>
    </div>
    <a href="<?php  echo $this->createMobileUrl('index', array('op'=>''));?>">toPC</a>

    <form method="post" action="./index.php">
        <input type="hidden" name="c" value="<?php  echo $_GPC['c'];?>">
        <input type="hidden" name="a" value="<?php  echo $_GPC['a'];?>">
        <input type="hidden" name="do" value="manager">
        <input type="hidden" name="m" value="<?php  echo $_GPC['m'];?>">
        <input type="hidden" name="op" value="hbinsert">
        <div class="mui-input-cell">
            多图上传:<?php  echo tpl_form_field_multi_image('imgs');?>
        </div>
        词1:<input name="words[]"/><br>
        词2:<input name="words[]"/><br>
        词3:<input name="words[]"/><br>
        <input type="submit"/>
    </form>
</div>
<div>
    <center>
        <?php  if($total == 0) { ?>数据为空<?php  } else { ?>
        <form method="post" action="./index.php">
            <input type="hidden" name="c" value="<?php  echo $_GPC['c'];?>">
            <input type="hidden" name="a" value="<?php  echo $_GPC['a'];?>">
            <input type="hidden" name="do" value="index">
            <input type="hidden" name="m" value="<?php  echo $_GPC['m'];?>">
            <input type="hidden" name="op" value="show">
            <?php  echo $pager;?>
        </form>
        <?php  } ?>
    </center>
</div>
<div>
    <center><h1>date:<?php  echo $date;?></h1></center>
    <form method="post" action="./index.php">
        <input type="hidden" name="c" value="<?php  echo $_GPC['c'];?>">
        <input type="hidden" name="a" value="<?php  echo $_GPC['a'];?>">
        <input type="hidden" name="do" value="index">
        <input type="hidden" name="m" value="<?php  echo $_GPC['m'];?>">
        <input type="hidden" name="op" value="update">
        <!--<input type="date" name="date" style="width: auto"/>-->
        <div>
            单图上传: <?php  echo tpl_form_field_image('img');?>
        </div>

        <input type="hidden" name="id" value="1">
        <input type="submit">
    </form>
</div>
<div><a href="<?php  echo $this->createWebUrl('manager', array('op'=>'hbyl'));?>">海报合成</a></div>
<img title="test" src="<?php  echo IA_ROOT.'/attachment/images/2/2018/05/ubxJjJ9iFJIxDfyjUVBF91cAv9yU9F.png' ;?>"/>
<img src="<?php  echo $this->createWebUrl('manager', array('op'=>'hbyl'));?>">
<?php (!empty($this) && $this instanceof WeModuleSite || 1) ? (include $this->template('common/footer', TEMPLATE_INCLUDEPATH)) : (include template('common/footer', TEMPLATE_INCLUDEPATH));?>
<?php defined('IN_IA') or exit('Access Denied');?><?php (!empty($this) && $this instanceof WeModuleSite || 1) ? (include $this->template('common/header', TEMPLATE_INCLUDEPATH)) : (include template('common/header', TEMPLATE_INCLUDEPATH));?>
数据表:<?php  echo $table;?>
<hr>
<?php  if(is_array($sql_d)) { foreach($sql_d as $key => $val) { ?>
index:<?php  echo $key;?> <br>
<form action="./index.php" method="post">
    <input type="hidden" name="c" value="<?php  echo $c;?>">
    <input type="hidden" name="a" value="<?php  echo $a;?>">
    <input type="hidden" name="do" value="table">
    <input type="hidden" name="m" value="<?php  echo $m;?>">
    <input type="hidden" name="op" value="update">
    <input type="hidden" name="t_name" value="<?php  echo $table;?>">
    <?php  if(is_array($val)) { foreach($val as $k => $v) { ?>

    <?php  echo $k;?>:<input name="<?php  echo $k;?>" value="<?php  echo $v;?>">
    <br>
    <?php  } } ?>
    <input type="submit" value="修改<?php  echo $table;?>表该行信息">&nbsp;&nbsp;&nbsp;
    <a href="<?php  echo $this->createWebUrl('table',array('op'=>'delete','t_name'=>$table,'ids[]'=>$val['id']));?>">删除行</a>
</form>
<hr>
<?php  } } ?>

<form action="./index.php" method="post">
    <input type="hidden" name="c" value="<?php  echo $c;?>">
    <input type="hidden" name="a" value="<?php  echo $a;?>">
    <input type="hidden" name="do" value="table">
    <input type="hidden" name="m" value="<?php  echo $m;?>">
    <input type="hidden" name="op" value="insert">
    <input type="hidden" name="t_name" value="<?php  echo $table;?>">
    <?php  if(is_array($paramcol)) { foreach($paramcol as $k => $v) { ?>
    <?php  if($v['Field'] != 'id') { ?>
    <?php  echo $v['Field'];?>:<input name="<?php  echo $v['Field'];?>" value=""><br>
    <?php  } ?>
    <?php  } } ?>
    <input type="submit" value="新增<?php  echo $table;?>行">
</form>

<form action="./index.php" method="post">
    <input type="hidden" name="c" value="<?php  echo $_GPC['c'];?>">
    <input type="hidden" name="a" value="<?php  echo $_GPC['a'];?>">
    <input type="hidden" name="do" value="table">
    <input type="hidden" name="m" value="<?php  echo $_GPC['m'];?>">
    <input type="hidden" name="op" value="detail">
    <?php  echo $pager;?>
</form>
<?php (!empty($this) && $this instanceof WeModuleSite || 1) ? (include $this->template('common/footer', TEMPLATE_INCLUDEPATH)) : (include template('common/footer', TEMPLATE_INCLUDEPATH));?>
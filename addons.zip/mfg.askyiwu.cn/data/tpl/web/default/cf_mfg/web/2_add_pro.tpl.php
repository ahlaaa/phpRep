<?php defined('IN_IA') or exit('Access Denied');?><?php (!empty($this) && $this instanceof WeModuleSite || 1) ? (include $this->template('common/header', TEMPLATE_INCLUDEPATH)) : (include template('common/header', TEMPLATE_INCLUDEPATH));?>
<!DOCTYPE html>
<html>
  <head>
    <title>添加商品-库存/规格</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <meta name="apple-mobile-web-app-capable" content="yes"/>
    <link href="../addons/<?php  echo $_GPC['m']?>/resource/assets/bootstrap-datetimepicker-master/css/bootstrap-datetimepicker.min.css" rel="stylesheet" />
    <link href="../addons/<?php  echo $_GPC['m']?>/resource/resources/css/jquery-ui-themes.css" type="text/css" rel="stylesheet"/>
    <!-- <link href="../addons/<?php  echo $_GPC['m']?>/resource/resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/> -->
    <!-- <link href="../addons/<?php  echo $_GPC['m']?>/resource/data/styles.css" type="text/css" rel="stylesheet"/> -->
    <!-- <link href="files/添加商品-库存_规格/styles.css" type="text/css" rel="stylesheet"/> -->
    <link href="../addons/<?php  echo $_GPC['m']?>/resource/assets/bootstrap-fileinput-master20151222/css/fileinput.css" type="text/css" rel="stylesheet"/>
    <script src="../addons/<?php  echo $_GPC['m']?>/resource/assets/jquery.min.js?v=2.1.4"></script>
    <!-- <script src="../addons/<?php  echo $_GPC['m']?>/resource/resources/scripts/jquery.min.js?v=2.1.4"></script> -->
    <script src="https://cdn.bootcss.com/jquery/2.1.1/jquery.min.js"></script>
    <link href="../addons/<?php  echo $_GPC['m']?>/resource/assets/bootstrap/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="../addons/<?php  echo $_GPC['m']?>/resource/assets/bootstrap/css/example-fluid-layout.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="../addons/<?php  echo $_GPC['m']?>/resource/resources/scripts/jquery-ui-1.8.10.custom.min.js"></script>
    <script src="../addons/<?php  echo $_GPC['m']?>/resource/resources/scripts/prototypePre.js"></script> 
    <script src="../addons/<?php  echo $_GPC['m']?>/resource/data/document.js"></script>
    <script src="../addons/<?php  echo $_GPC['m']?>/resource/resources/scripts/prototypePost.js"></script>
    <script src="../addons/<?php  echo $_GPC['m']?>/resource/files/添加商品-库存_规格/data.js"></script> 
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return '../addons/<?php  echo $_GPC["m"]?>/resource/resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return '../addons/<?php  echo $_GPC["m"]?>/resource/resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return '../addons/<?php  echo $_GPC["m"]?>/resource/resources/reload.html'; };
    </script>
    <style type="text/css">
      body{
        height: auto;
      }
      input{
        border: none;
        width: 100%;
        line-height: 2em;
      }
      input[type=radio]{
        cursor: pointer;
        width: auto;
        line-height: 0em;
        box-shadow: none;
      }
      input[type=button]{
        cursor: pointer;
        width: auto;
        line-height: 1.4em;
      }
      select{
        cursor:pointer;
        box-shadow: none;
      }
      select option{
        cursor:pointer;
      }
      .col-md-2{
        text-align: right;
      }
      span{
        font-family: 'STHeitiSC-Medium', 'Heiti SC Medium', 'Heiti SC';
        font-weight: 700;
        font-style: normal;
        font-size: 14px;
        color: #698191;
        margin-top: 0px;
        display: inline-block;
      }
      input{
        border:1px solid #698191;
        border-radius: 3px;
        box-shadow: 2px 2px 2px #87c5ee;
      }
      .text>span{
        font-family: 'STHeitiSC-Light', 'Heiti SC Light', 'Heiti SC';
        font-weight: 200;
        font-style: normal;
        font-size: 10px;
        color: #698191;
        margin-top: 0px;
      }
      label{
        cursor: pointer;
      }
      label>input{
        box-shadow: none;
      }
    </style>
  </head>
  <div id="main" style="position: relative;max-width: 100%;border: 1px solid">
    <div id="top" style="position: absolute;width: 950px;">
        <img id="u299_img" class="img " src="../addons/<?php  echo $_GPC['m']?>/resource/images/产品-商品添加/u196.png"><span>添加商品</span>
      <HR style="FILTER: progid:DXImageTransform.Microsoft.Shadow(color:#987cb9,direction:145,strength:15)" width="100%" color="#987cb9" SIZE=2>
    </div>
    <div class="container" style="position: absolute;top: 56px">
        <div class="row clearfix" style="">
          <div class="col-md-1 column">
              <span>基本信息</span>
              <img id="u306_img" class="img " src="../addons/<?php  echo $_GPC['m']?>/resource/images/添加商品-库存_规格/u306.png">
          </div>
          <div class="col-md-9 column">
              <!--行-->
              <div class="row clearfix">
                <div class="col-md-2 column">
                  <span style="">排序</span>
                </div>
                <div class="col-md-8 column">
                  <div class="text">
                    <input type="number" name="sort" value="0" />
                    <span><font>数字越大，排名越靠前，如果为空，默认排序方式为创建时间</font></span>
                  </div>
                </div>
              </div>
              <!--/行-->
              <br>
              <!--行-->
              <div class="row clearfix">
                <div class="col-md-2 column">
                  <span style="">商品名称</span>
                </div>
                <div class="col-md-5 column">
                  <div class="text">
                    <input type="text" name="pro_name" value="" />
                  </div>
                </div>
                <div class="col-md-3 column">
                  <div class="text" style="border: 0.66px solid;padding: 5px;height: 23px;width: 133px;margin-top: 8px;">
                      <span style="font-size: 14px"><font>单位, 如：个/件/包</font></span>
                  </div>
                </div>
              </div>
              <!--/行-->
              <br>
              <!--行-->
              <div class="row clearfix">
                <div class="col-md-2 column">
                  <span style="">关键字</span>
                </div>
                <div class="col-md-8 column">
                  <div class="text">
                      <input type="text" name="pro_key" value="" />
                    <span><font>商品关键字，能准确搜到商品，比如 海尔</font></span>
                  </div>
                </div>
              </div>
              <!--/行-->
              <br>
              <!--行-->
              <div class="row clearfix">
                <div class="col-md-2 column">
                  <span style="">商品类型</span>
                </div>
                <div class="col-md-8 column">
                  <div class="text">
                    <label>
                      <input type="radio" name="pro_type" value="1" checked /><span>实体商品</span>
                    </label>
                    <label style="margin-left: 12px">
                      <input type="radio" name="pro_type" value="2" /><span>虚拟商品</span>
                    </label>
                  </div>
                </div>
              </div>
              <!--/行-->
              <br>
              <!--行-->
              <div class="row clearfix">
                <div class="col-md-2 column">
                  <span style="">商品分类</span>
                </div>
                <div class="col-md-8 column">
                  <div class="text">
                    
                      <input type="text" name="pro_to_type" value="" />
                   
                  </div>
                </div>
              </div>
              <!--/行-->
              <br>
              <!--行-->
              <div class="row clearfix">
                <div class="col-md-2 column">
                  <span style="">商品图片</span>
                </div>
                <div class="col-md-8 column">
                  <div class="text" style="    background-color: lightgrey;padding-left: 172px;">
                      <label for="fileinput" id="fileinput1" style="margin-top: 5px;font-size: 15px;opacity: 0.5;cursor: pointer;">点击此处触发上传</label>
                      <div id="u320_div1" style="display: none;">
                          <input id="fileinput" multiple type="file" class="file" data-show-upload="false" data-show-preview="true" />
                      </div>
                      <input type="button" onclick="javascript:upload()" id="upload_button" value="上传" />
                  </div>
                </div>
              </div>
              <!--/行-->
              <br>
              <!--行-->
              <div class="row clearfix">
                <div class="col-md-2 column">
                 
                </div>
                <div class="col-md-8 column">
                  <div class="text">
                      <div style="max-width: 500px;width: 100%;height: 80px;background: rgba(0, 24, 35, 0.15);padding-top: 5px;" id="img_see">
                      
                      </div>
                      <span><font>第一张为缩略图，建议为正方形图片，其他为详情页面图片，尺寸建议宽度为640，并保持图片大小一致您可以拖动图片改变其显示顺序</font></span>
                  </div>
                  <div class="row clearfix">
                    <div><label><input type="checkbox" style="width: 50px;height: 20px;opacity: 0.4;box-shadow: none" name="show_detail" /><span>详情显示首图</span></label></div>
                  </div>
                </div>
              </div>
              <!--/行-->

          <script>
            $(function(){
              fishFileInput();
            })
            function upload(){
              console.log("upload");
              $('#fileinput').fileinput('upload');
            }
            $("#fileinput").on("filebatchselected", function(event, files) {
                
                var src = $('.file-preview-image');
                $("#img_see").html("");
                if(src.length == 5){
                  var $sty = $("#fileinput1").attr("style");
                  $sty = $sty.substring(0,$sty.lastIndexOf("cursor"));
                  $sty += "cursor: no-drop;";
                  $("#fileinput1").attr("style",$sty);
                  //data-disabled="true"
                  $("#fileinput1").attr("for","");
                  $("#fileinput1").html("最多上传5张");
                  // $("#upload_button").hide();
                }
                $.each(src,function(k,v){
                    var c_div = create_div(k);
                    console.log(v);
                    $("#img_see").append(c_div);
                    $('.file-preview-image').attr('style','max-width:100%;max-height:100%;');
                    $("#u323"+k).append(v);
                })
            });
            function create_div(len){
                var c_div = '<div id="u323'+len+'" class="ax_default _图片" style="position:relative;border:1px solid;margin-left: 15px;border-radius: 5%;display: inline-block;padding: 5px;;width: 69px;height: 71px;"><div style="position:absolute;top: -4px;right: -11px;cursor:pointer" onclick="javascript:del(this)">X</div</div>';
              
                return c_div;
            }
            function del(e){
              $div = $(e).parents("div")[0];
              if(confirm("确认删除图片?")){
                  $($div).remove();
                  var $sty = $("#fileinput1").attr("style");
                  $sty = $sty.substring(0,$sty.lastIndexOf("cursor"));
                  $sty += "cursor: pointer;";
                  $("#fileinput1").attr("style",$sty);
                  $("#fileinput1").attr("for","fileinput");
                  $("#fileinput1").html("点击此处触发上传");
                  // $("#upload_button").show();
              }
                
            }
            //初始化鱼类名录信息上传的fileinput控件
            function fishFileInput(ctrlName, uploadUrl) {
              console.log("upload1");
                $("#fileinput").fileinput({
                    language: 'zh', //设置语言
                    uploadUrl: "https://ygx.askyiwu.cn/api/admin/upload", //上传的地址
                    enctype: 'multipart/form-data',
                    allowedFileExtensions : ['jpg', 'png','bmp','jpeg'],//接收的文件后缀
                    showUpload: false, //是否显示上传按钮
                    showPreview: true, //展前预览
                    showCaption: false,//是否显示标题
                    maxFileSize : 10000,//上传文件最大的尺寸
                    maxFilesNum : 10,//上传文件最大的个数
                    dropZoneEnabled: false,//是否显示拖拽区域
                    browseClass: "btn btn-primary", //按钮样式
                    uploadAsync: true,
                    layoutTemplates :{
                        // actionDelete:'', //去除上传预览的缩略图中的删除图标
                        actionUpload:'',//去除上传预览缩略图中的上传图片；
                        actionZoom:''   //去除上传预览缩略图中的查看详情预览的缩略图标。
                    },
                    // uploadExtraData:function (previewId, index) {
                    //     //向后台传递id作为额外参数，是后台可以根据id修改对应的图片地址。
                    //     var obj = {};
                    //     obj.name = "file";
                    //     console.log(obj);
                    //     return obj;
                    // }
                }).on("filebatchuploadsuccess", function(event, data) {
                  console.log(data);
                    if(data.response){
                      console.log(data.response);
                        // closeModal('fishAddDetail') //关闭模态框。
                        // $("#bootstraptable_fishcontent").bootstrapTable("refresh");
                    }
                }).on('fileerror', function(event, data, msg) {  //一个文件上传失败
                    console.log('文件上传失败！'+data);
                }).on("fileuploaded", function (event, data, previewId, index) {    //一个文件上传成功  
                    console.log(data);  
      
                });
            }
          </script>
          <br>
          <!--行-->
          <div class="row clearfix">
            <div class="col-md-2 column">
              <span style="">运费设置</span>
            </div>
            <div class="col-md-8 column">
              <div class="row clearfix">
                  <div class="col-md-3 column">
                        <label><input type="radio" name="fee_conf" checked /><span><font>运费模板</font></span></label>
                  </div>
                  <div class="col-md-8 column">
                      <select class="form-control" style="-webkit-appearance:none;height: 99%;padding: 5px 44%;">
                          <option value="model">默认</option>
                          <option value="model1">模板1</option>
                          <option value="model2">模板2</option>
                          <option value="model3">模板3</option>
                      </select>
                  </div>
              </div>
              <div class="row clearfix" style="margin-left: 9px;">
                <div class="text">
                  <span>如果开启了同城配送，系统优先使用同城配送方式，如果未开启同城配送或者超出同城配送范围则使用普通快递方式计算运费</span>
                </div>
              </div>
              <div class="row clearfix">
                  <div class="col-md-3 column">
                    <label><input type="radio" name="fee_conf" /><span><font>统一邮费</font></span></label>
                  </div>
                  <div class="col-md-8 column">
                      <select class="form-control" style="-webkit-appearance:none;height: 99%;padding: 5px 44%;">
                          <option value="fee">0.00</option>
                          <option value="fee1">1.00</option>
                          <option value="fee2">2.00</option>
                          <option value="fee3">3.00</option>
                      </select>
                  </div>
              </div>
            </div>
          </div>
          <!--/行-->
          <!--行-->
          <div class="row clearfix">
            <div class="col-md-2 column">
              <span style="">自定义标签</span>
            </div>
            <div class="col-md-6 column">
                <select class="form-control" style="-webkit-appearance:none;height: 99%;padding: 5px 44%;">
                    <option value="tag1">标签1</option>
                    <option value="tag2">标签2</option>
                    <option value="tag3">标签3</option>
                    <option value="tag4">标签4</option>
                </select>
            </div>
            <div class="col-md-2 column">
                <div class="text" style="border: 0.66px solid;padding: 5px;height: 23px;width: 133px;margin-top: 8px;">
                    <span style="font-size: 14px"><font>单位, 如：个/件/包</font></span>
                </div>
            </div>
          </div>
          <!--/行-->
          <!--行-->
          <div class="row clearfix">
            <div class="col-md-2 column">
              <span style="">商品分类</span>
            </div>
            <div class="col-md-6 column">
                <select class="form-control" style="-webkit-appearance:none;height: 99%;padding: 5px 44%;">
                    <option value="type1">类1</option>
                    <option value="type2">类2</option>
                    <option value="type3">类3</option>
                    <option value="type4">类4</option>
                </select>
            </div>
            <div class="col-md-2 column">
                <div class="text" style="border: 0.66px solid;padding: 5px;height: 23px;width: 133px;margin-top: 8px;">
                    <span style="font-size: 14px"><font>ID搜索</font></span>
                </div>
            </div>
          </div>
          <!--/行-->
          <!--行-->
          <div class="row clearfix">
              <div class="col-md-2 column">
                <span style="">商品原价</span>
              </div>
              <div class="col-md-4 column">
                  <div><label><input type="text" style="width: 50px;height: 20px;opacity: 0.4;box-shadow: none" name="price" /><span>元</span></label></div>
              </div>
          </div>
        </div>
      </div>
    </div>
  </div>
    <!-- <script src="../addons/<?php  echo $_GPC['m']?>/resource/assets/bootstrap/js/bootstrap.min.js?v=3.3.6"></script> -->
    
    <script src="../addons/<?php  echo $_GPC['m']?>/resource/assets/bootstrap-datetimepicker-master/js/moment-with-locales.js"></script>
	<script src="https://cdn.bootcss.com/bootstrap/3.3.7/js/bootstrap.min.js?v=3.3.6"></script>

    <script src="../addons/<?php  echo $_GPC['m']?>/resource/assets/bootstrap-datetimepicker-master/js/bootstrap-datetimepicker.js"></script>
    <script src="../addons/<?php  echo $_GPC['m']?>/resource/assets/bootstrap-datetimepicker-master/js/locales/bootstrap-datetimepicker.zh-CN.js"></script>
    <script src="../addons/<?php  echo $_GPC['m']?>/resource/assets/bootstrap-datetimepicker-master/js/locales/bootstrap-datetimepicker.fr.js"></script>
    <script src="../addons/<?php  echo $_GPC['m']?>/resource/assets/bootstrap-fileinput-master20151222/js/fileinput.js"></script>
    <script src="../addons/<?php  echo $_GPC['m']?>/resource/assets/bootstrap-fileinput-master20151222/js/fileinput_locale_zh.js"></script>
    <script type="text/javascript">
          
            设置日期时间控件
            $(".form_datetime").datetimepicker({
                    // format: "yyyy MM dd - hh:ii",
                    // autoclose: true,
                    // todayBtn: true,
                    // // pickerPosition: "bottom-right",
                    // locale: moment.locale('zh-cn'),
                    // language: 'zh-CN',
                    weekStart: 1,
                    todayBtn: true,
                    autoclose: 1,
                    todayHighlight: 1,
                    // pickerPosition: "top-left",
                    startView: 2,
                    minView: 2,
                    forceParse: 0,
            });
           
        
    </script>
  </body>
</html>
<!-- <?php (!empty($this) && $this instanceof WeModuleSite || 1) ? (include $this->template('common/footer', TEMPLATE_INCLUDEPATH)) : (include template('common/footer', TEMPLATE_INCLUDEPATH));?> -->
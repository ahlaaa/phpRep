<?php defined('IN_IA') or exit('Access Denied');?><?php (!empty($this) && $this instanceof WeModuleSite || 1) ? (include $this->template('common/header', TEMPLATE_INCLUDEPATH)) : (include template('common/header', TEMPLATE_INCLUDEPATH));?>
<div>

    <a href="<?php  echo $this->createWebUrl('manager',array('op'=>'levelshow'));?>">等级管理</a>
    <!--<form action="./index.php" method="post">-->
    <!--<input type="hidden" name="c" value="<?php  echo $c;?>">-->
    <!--<input type="hidden" name="a" value="<?php  echo $a;?>">-->
    <!--<input type="hidden" name="do" value="manager">-->
    <!--<input type="hidden" name="m" value="<?php  echo $m;?>">-->
    <!--<input type="hidden" name="op" value="levelinsert">-->
    <!--<div class="mui-input-cell">-->
    <!--多图上传:<?php  echo tpl_form_field_multi_image('imgs');?>-->
    <!--</div>-->
    <!--<input type="submit"/>-->
    <!--</form>-->
    <hr>
    <a href="<?php  echo $this->createWebUrl('manager',array('op'=>'sjshow'));?>">商家管理</a>
    <hr>
    <a href="<?php  echo $this->createWebUrl('manager',array('op'=>'rewardshow'));?>">营销管理</a>
    <hr>
    <a href="<?php  echo $this->createWebUrl('order',array('op'=>''));?>">订单管理</a>
    <hr>
    <a href="<?php  echo $this->createWebUrl('manager',array('op'=>'hbshow'));?>">海报配置</a>

    <hr>
</div>
<?php (!empty($this) && $this instanceof WeModuleSite || 1) ? (include $this->template('common/footer', TEMPLATE_INCLUDEPATH)) : (include template('common/footer', TEMPLATE_INCLUDEPATH));?>
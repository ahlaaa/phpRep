<?php defined('IN_IA') or exit('Access Denied');?><?php (!empty($this) && $this instanceof WeModuleSite || 1) ? (include $this->template('common/header', TEMPLATE_INCLUDEPATH)) : (include template('common/header', TEMPLATE_INCLUDEPATH));?>
<div>

</div>
<div>

    <?php  if(is_array($data)) { foreach($data as $key => $val) { ?>
    <form action="./index.php" method="post">
        <input type="hidden" name="c" value="<?php  echo $c;?>">
        <input type="hidden" name="a" value="<?php  echo $a;?>">
        <input type="hidden" name="do" value="manager">
        <input type="hidden" name="m" value="<?php  echo $m;?>">
        <input type="hidden" name="op" value="rewardupdate">
        <?php  if(is_array($val)) { foreach($val as $k => $v) { ?>
        <?php  if($k == 'type_id') { ?>type_name:<input type="text" name="tid" value="<?php  echo $arr_type[$v];?>"/>
        <input type="text" name="<?php  echo $k;?>" value="<?php  echo $v;?>" hidden/>
        <?php  } else if($k == 'pro_id') { ?>pro_name:<input type="text" name="pid" value="<?php  echo $arr_ni[$v];?>"/>
        <input type="text" name="<?php  echo $k;?>" value="<?php  echo $v;?>" hidden/>
        <?php  } else { ?><?php  echo $k;?>:<input type="text" name="<?php  echo $k;?>" value="<?php  echo $v;?>"/><?php  } ?><br>
        <?php  } } ?>
        <input type="submit" value="更新">&nbsp;&nbsp;&nbsp;&nbsp;
        <a href="<?php  echo $this->createWebUrl('manager',array('op'=>'rewarddelete','ids[]'=>$val['id']));?>">删除</a>
    </form>
    <hr>
    <?php  } } ?>

    <form action="./index.php" method="post">
        <input type="hidden" name="c" value="<?php  echo $c;?>">
        <input type="hidden" name="a" value="<?php  echo $a;?>">
        <input type="hidden" name="do" value="manager">
        <input type="hidden" name="m" value="<?php  echo $m;?>">
        <input type="hidden" name="op" value="rewardinsert">
        <?php  if(is_array($paramscol)) { foreach($paramscol as $k => $v) { ?>
        <?php  if($v['Field'] != 'id') { ?>
        <?php  if($v['Field'] == 'type_id') { ?>type_name:
        <select name="type_id">
            <?php  if(is_array($arr_type)) { foreach($arr_type as $k => $v) { ?>
            <option name="type_id" value="<?php  echo $k;?>"><?php  echo $v;?></option>
            <?php  } } ?>
        </select>
        <?php  } else if($v['Field'] == 'pro_id') { ?>pro_name:
        <select name="pro_id">
            <?php  if(is_array($arr_ni)) { foreach($arr_ni as $k => $v) { ?>
            <option name="pro_id" value="<?php  echo $k;?>"><?php  echo $v;?></option>
            <?php  } } ?>
        </select>
        <?php  } else { ?><?php  echo $v['Field'];?>:<input type="text" name="<?php  echo $v['Field'];?>" value=""/><?php  } ?><br>
        <?php  } ?>
    <?php  } } ?>
        <input type="submit" value="新增奖励">
    </form>
    <form action="./index.php" method="post">
        <input type="hidden" name="c" value="<?php  echo $c;?>">
        <input type="hidden" name="a" value="<?php  echo $a;?>">
        <input type="hidden" name="do" value="manager">
        <input type="hidden" name="m" value="<?php  echo $m;?>">
        <input type="hidden" name="op" value="rewardshow">
        <?php  echo $pager;?>
    </form>
</div>
<?php (!empty($this) && $this instanceof WeModuleSite || 1) ? (include $this->template('common/footer', TEMPLATE_INCLUDEPATH)) : (include template('common/footer', TEMPLATE_INCLUDEPATH));?>
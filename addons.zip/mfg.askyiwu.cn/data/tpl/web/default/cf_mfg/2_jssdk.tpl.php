<?php defined('IN_IA') or exit('Access Denied');?><html>
<head>
    <title>测试 register_jssdk</title>
    <?php  echo register_jssdk(true);?>
</head>

<body>
<ul class="nav nav-tabs" style="margin-bottom: 10px;">
    <li><a href="<?php  echo $this->createMobileUrl('store', array('op'=>'display'));?>">全部商品</a></li>
    <li class="active"><a href="<?php  echo $this->createMobileUrl('jssdk');?>">分享测试</a></li>
</ul>

<script>
    wx.ready(function () {
        sharedata = {
            title: '微信JS-SDK Demo',
            desc: '微信JS-SDK,帮助第三方为用户提供更优质的移动web服务',
            link: 'http://demo.open.weixin.qq.com/jssdk/',
            imgUrl: 'http://mmbiz.qpic.cn/mmbiz/icTdbqWNOwNRt8Qia4lv7k3M9J1SKqKCImxJCt7j9rHYicKDI45jRPBxdzdyREWnk0ia0N5TMnMfth7SdxtzMvVgXg/0',
            success: function () {
                alert('success');
            },
            cancel: function () {
                alert('cancel');
            }
        };
        wx.onMenuShareAppMessage(sharedata);
    });
</script>
</body>
</html>
<?php defined('IN_IA') or exit('Access Denied');?><?php (!empty($this) && $this instanceof WeModuleSite || 0) ? (include $this->template('common/header', TEMPLATE_INCLUDEPATH)) : (include template('common/header', TEMPLATE_INCLUDEPATH));?>
<div class="welcome-container" id="js-home-welcome" ng-controller="WelcomeCtrl" ng-cloak>
	<div class="welcome-container">
		<div class="panel we7-panel account-stat">
			<div class="panel-heading">
				今日关键指标/昨日关键指标
			</div>
			<div class="panel-body we7-padding-vertical">
				<div class="col-sm-3 text-center">
					<div class="title">新关注</div>
					<div>
						<span class="today" ng-init="0" ng-bind="fans_kpi.today.new"></span>
						<span class="pipe">/</span>
						<span class="yesterday" ng-init="0" ng-bind="fans_kpi.yesterday.new"></span>
					</div>
				</div>
				<div class="col-sm-3 text-center">
					<div class="title">取消关注</div>
					<div>
						<span class="today" ng-init="0" ng-bind="fans_kpi.today.cancel"></span>
						<span class="pipe">/</span>
						<span class="yesterday" ng-init="0" ng-bind="fans_kpi.yesterday.cancel"></span>
					</div>
				</div>
				<div class="col-sm-3 text-center">
					<div class="title">净增关注</div>
					<div>
						<span class="today" ng-init="0" ng-bind="fans_kpi.today.jing_num"></span>
						<span class="pipe">/</span>
						<span class="yesterday" ng-init="0" ng-bind="fans_kpi.yesterday.jing_num"></span>
					</div>
				</div>
				<div class="col-sm-3 text-center">
					<div class="title">累计关注</div>
					<div>
						<span class="today" ng-init="0" ng-bind="fans_kpi.today.cumulate"></span>
					</div>
				</div>
			</div>
		</div>
		<div class="panel we7-panel notice notice-tab">
			<div class="panel-heading">
				<?php  if(permission_check_account_user('see_notice_post')) { ?><a href="./index.php?c=article&a=notice&do=post" class="color-default pull-right we7-margin-left">+新建</a><?php  } ?>
				<a href="./index.php?c=article&a=notice-show" class="color-default pull-right">更多</a>
				<div class="menu">
					<span class="topic active notice">公告</span>
					
						<span class="topic we7notice">微擎公告</span>
					
				</div>
			</div>
			<ul class="list-group active">
				<li class="list-group-item" ng-repeat="notice in notices" ng-if="notices">
					<a ng-href="{{notice.url}}" class="text-over" target="_blank" ng-style="{'color': notice.style.color, 'font-weight': notice.style.bold ? 'bold' : 'normal'}" ng-bind="notice.title"></a>
					<span class="pull-right color-gray" ng-bind="notice.createtime"></span>
				</li>
				<li class="list-group-item text-center" ng-if="!notices">
					<span>暂无数据</span>
				</li>
			</ul>
			
				<ul class="list-group">
					<script type="text/javascript" src="//bbs.we7.cc/api.php?mod=js&bid=20"></script>
				</ul>
			
		</div>	
		
			<div class="panel we7-panel apply-list">
				<div class="panel-heading">
					<a href="http://s.we7.cc" target="_blank" class="color-default pull-right">查看更多应用</a>
					微擎推荐
				</div>
				<div class="panel-body text-center">
					<span href="javascript:;" ng-if="!last_modules && loaderror == 0">数据加载中...</span>
					<span href="javascript:;" ng-if="!last_modules && loaderror == 1">数据加载失败，<a href="javascript:;" class="btn-link" ng-click="get_last_modules()">点击重试</a></span>
					<a ng-href="{{module.url}}" target="_blank" class="apply-item" ng-if="last_modules && !module.wxapp && module.logo && $index+1 < 8" class="apply-item" ng-repeat="module in last_modules">
						<img ng-src="{{module.logo}}" class="apply-img"/>
						<span>{{module.title|limitTo:6}}</span>
					</a>
				</div>
			</div>
		
	</div>
</div>
<script>
	angular.module('homeApp').value('config', {
		notices: <?php echo !empty($notices) ? json_encode($notices) : 'null'?>,
	});
	angular.bootstrap($('#js-home-welcome'), ['homeApp']);
	$(function(){
		$('[data-toggle="tooltip"]').tooltip();
		var $topic = $('.welcome-container .notice .menu .topic');
		var $ul = $('.welcome-container .notice ul');

		$topic.mouseover(function(){
			var $this = $(this);
			var $index = $this.index();
			if ($this.is('.we7notice')) {
				$this.parent().prev().hide();
			} else {
				$this.parent().prev().show();
			}
			$topic.removeClass('active');
			$this.addClass('active');
			$ul.removeClass('active');
			$ul.eq($index).addClass('active');
		})
	})
</script>
<?php (!empty($this) && $this instanceof WeModuleSite || 0) ? (include $this->template('common/footer', TEMPLATE_INCLUDEPATH)) : (include template('common/footer', TEMPLATE_INCLUDEPATH));?>

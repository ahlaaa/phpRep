<?php defined('IN_IA') or exit('Access Denied');?><?php (!empty($this) && $this instanceof WeModuleSite || 0) ? (include $this->template('common/header', TEMPLATE_INCLUDEPATH)) : (include template('common/header', TEMPLATE_INCLUDEPATH));?>
<div class="form-horizontal" id="js-cloud-diagnose" ng-controller="CloudDiagnoseCtrl" ng-cloak>
	<h5 class="page-header">云服务状态诊断</h5>
	<div class="form-group">
		<label class="col-sm-2 control-label">站点URL</label>
		<div class="col-sm-10">
			<p class="form-control-static"><?php  echo $_W['siteroot'];?></p>
		</div>
	</div>
	<div class="form-group">
		<label class="col-sm-2 control-label">站点ID</label>
		<div class="col-sm-10">
			<p class="form-control-static"><?php  echo $_W['setting']['site']['key'];?></p>
		</div>
	</div>
	<div class="form-group">
		<label class="col-sm-2 control-label">通信密钥</label>
		<div class="col-sm-10">
			<p class="form-control-static"><?php  echo substr($_W['setting']['site']['token'], 0, 5) . '*****' . substr($_W['setting']['site']['token'], -5, 5);?></p>
			<div class="help-block">
				<a href="javascript:;" class="color-default" ng-click="showToken()">查看全部</a>&nbsp;&nbsp;
				<input type="hidden" value="<?php  echo $_W['setting']['site']['token'];?>" id="token" />
			</div>
			<div class="help-block">请查看您的站点ID和通信密钥, 需要保证与<a href="<?php  echo url('cloud/profile');?>">云服务平台记录</a>的值一致, 否则不能正常使用云平台的各项服务. </div>
		</div>
	</div>
	<div class="form-group">
		<label class="col-sm-2 control-label">系统版本</label>
		<div class="col-sm-10">
			<p class="form-control-static">WeEngine<?php  echo IMS_VERSION?><?php  echo IMS_FAMILY?> (Release <?php  echo IMS_RELEASE_DATE?>)</p>
		</div>
	</div>
	<div class="form-group">
		<div class="col-sm-2"></div>
		<div class="col-sm-10">
			<form action="" method="post" role="form" onsubmit="return confirm('如果您的系统没有发生云服务链接异常, 请不要使用重置功能.');">
				<input type="submit" name="submit" value="重置站点ID和通信密钥" class="btn btn-primary" />
				<input type="hidden" name="token" value="<?php  echo $_W['token'];?>" />
			</form>
			<div class="help-block">如果您的站点ID和通信密钥与您绑定的站点信息中的记录不一致, 或访问云服务失败并多次重试后无效时. 请点击重置按钮, 重新注册您的站点信息(如果需要使用相同的微擎论坛账号绑定, 需要先在云服务后台中解除绑定) </div>
		</div>
	</div>

	<h5 class="page-header">云服务网络诊断</h5>
	<div class="form-group">
		<label class="col-sm-2 control-label">服务器时间检查</label>
		<div class="col-sm-10">
			<p class="form-control-static" id="check-time">检测中...</p>
		</div>
	</div>
	<div class="form-group">
		<label class="col-sm-2 control-label">DNS解析函数</label>
		<div class="col-sm-10">
			<p class="form-control-static"><?php  if(function_exists('gethostbyname')) { ?><i class="fa fa-check text-success"></i> 正常<?php  } else { ?><i class="fa fa-remove text-warning"></i> 异常<?php  } ?></p>
		</div>
	</div>
	<div class="form-group">
		<label class="col-sm-2 control-label">云平台域名解析</label>
		<div class="col-sm-10 js-checkip">
			<?php  if(is_array($checkips)) { foreach($checkips as $index => $ip) { ?>
				<p class="form-control-static">云节点<?php  echo $index+1;?>：<span id="serverdnsip"><?php  echo $ip;?></span>; 速率测试：<span class="form-control-static" id="checkresult">检测中...</span></p>
			<?php  } } ?>
		</div>
	</div>
	<div class="form-group">
		<label class="col-sm-2 control-label">绑定云服务接口IP</label>
		<div class="col-sm-10">
			<p class="form-control-static"><?php  if(!empty($_W['setting']['cloudip'])) { ?>自定义接口IP：<?php  echo $_W['setting']['cloudip']['ip'];?><?php  } ?>&nbsp;&nbsp;<a href="javascript:;" class="color-default" data-toggle="modal" data-target="#set-server-ip">设置接口IP</a></p>
		</div>
	</div>
	<div class="form-group">
		<label class="col-sm-2 control-label">云平台到站点测试</label>
		<div class="col-sm-10">
			<p class="form-control-static" id="check-touch">检测中...</p>
		</div>
	</div>
</div>
<form method="post">
<div class="modal fade in form-horizontal" id="set-server-ip" tabindex="-1" role="dialog" aria-hidden="false">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">设置云服务ip地址</h4>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<label class="control-label col-xs-3">云服务ip</label>
					<div class="col-xs-9">
						<input type="text" class="form-control" name="ip" value="<?php  echo $_W['setting']['cloudip']['ip'];?>" />
						<span class="help-block">如果您解析的云服务ip异常，可以在此手动设置</span>
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">取消</button>
				<button type="submit" class="btn btn-primary" name="updateserverip" value="ok">确认</button>
				<input type="hidden" name="token" value="<?php  echo $_W['token'];?>" />
			</div>
		</div>
	</div>
</div>
</form>
<script>
angular.module('cloudApp').value('config', {
	version: "<?php  echo IMS_VERSION?>",
	siteurl: "<?php  echo $_W['siteroot']?>",
	date: <?php  echo $_W['timestamp']?>,
});
angular.bootstrap($('#js-cloud-diagnose'), ['cloudApp']);
</script>
<?php (!empty($this) && $this instanceof WeModuleSite || 0) ? (include $this->template('common/footer', TEMPLATE_INCLUDEPATH)) : (include template('common/footer', TEMPLATE_INCLUDEPATH));?>